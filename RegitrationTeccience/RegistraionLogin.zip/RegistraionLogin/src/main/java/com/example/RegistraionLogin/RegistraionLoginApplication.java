package com.example.RegistraionLogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistraionLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistraionLoginApplication.class, args);
	}

}
