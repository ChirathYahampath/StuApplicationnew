package com.example.RegistraionLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistraionLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
